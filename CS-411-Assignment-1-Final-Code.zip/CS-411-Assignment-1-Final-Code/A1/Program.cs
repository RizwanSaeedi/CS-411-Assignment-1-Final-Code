﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Welcome To Student Record Management System" + Environment.NewLine);

                Student student = new Student(); // creating object from student class

                Console.WriteLine("Please Enter Student's Name:");
                string name = Console.ReadLine();
                student.setName(name);

                Console.WriteLine("\nPlease Enter Student's ID:");
                string ID = Console.ReadLine();
                student.setID(ID);

                Console.WriteLine("\nPlease Enter Student's Age:");
                string age = Console.ReadLine();
                student.setAge(Convert.ToInt16(age));

                Console.WriteLine("\nPlease Enter Student's Semester :");
                string Semester = Console.ReadLine();
                student.setSemester(Convert.ToInt16(Semester));

            repeat:
                Console.WriteLine(Environment.NewLine + "Student's Record Entered Successfully!" + Environment.NewLine);

                Console.WriteLine();
                Console.WriteLine("Press 'S' to show entered record or press'N' to enter new record or Press 'E' to Exit");
                string selection = Console.ReadLine();
                selection = selection.ToUpper();

                if (selection.Equals("S"))
                {
                    // show students  data
                    Console.WriteLine("\nEntered Data is as follows:\n");
                    Console.WriteLine("Student's Name:" + student.Name);
                    Console.WriteLine("Student's ID:" + student.ID);
                    Console.WriteLine("Student's Age:" + student.Age);
                    Console.WriteLine("Student's Semester:" + student.semester);

                    goto repeat;
                }
                else if (selection.Equals("N"))
                {
                    // enter new record
                    continue;
                }
                else if (selection.Equals("E"))
                {
                    // exit loop
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid Input");
                }
            }
        }
    }
}
