﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1
{
    class Student : User
    {
        public static foo;
        public string ID;
        public int semester;

        public string getID()
        {
            return ID;
        }
        public int getSemester()
        {
            return semester;
        }

        public void setID(string _id)
        {
            ID = _id;
        }
        public void setSemester(int _semester)
        {
            semester = _semester;
        }
    }
}
