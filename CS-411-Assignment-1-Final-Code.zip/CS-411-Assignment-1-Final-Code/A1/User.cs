﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1
{
    class User
    {
        public string Name;
        public int Age;

        public string getName()
        {
            return Name;
        }
        public int getAge()
        {
            return Age;
        }

        public void setName(string _name)
        {
            Name = _name;
        }
        public void setAge(int _age)
        {
            Age = _age;
        }
    }
}
